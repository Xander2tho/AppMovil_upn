package com.example.apmovproyecto_gestionfinancierapersonal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    //crear botón añadir (ingresos o gastos)
    private ImageButton btn_anadir;

    private String txt_gastos_lista[] = {"Compras", "Comida"};
    private int img_gastos_lista[] = {R.drawable.compras, R.drawable.comida};

    ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //listView = findViewById(R.id.init_List);
        //Adap_base_pers adap_aux = new Adap_base_pers(getApplicationContext(), txt_gastos_lista, img_gastos_lista);
        //listView.setAdapter(adap_aux);

        btn_anadir = (ImageButton)findViewById(R.id.img_añadir);
        btn_anadir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, activity_add.class);
                startActivity(i);
            }
        });

    }
}