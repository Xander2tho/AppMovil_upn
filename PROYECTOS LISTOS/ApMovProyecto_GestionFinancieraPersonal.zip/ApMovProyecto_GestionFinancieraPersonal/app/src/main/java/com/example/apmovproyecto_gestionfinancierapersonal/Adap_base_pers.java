package com.example.apmovproyecto_gestionfinancierapersonal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class Adap_base_pers extends BaseAdapter {

    Context context;
    String [] lista_gastos;
    int [] lista_imgs;

    LayoutInflater inflador;

    public Adap_base_pers(Context ctx, String [] gastos_nombres, int [] gastos_imgs){
        this.context = ctx;
        this. lista_gastos = gastos_nombres;
        this.lista_imgs = gastos_imgs;
    }

    @Override
    public int getCount() {
        return lista_gastos.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflador.inflate(R.layout.activity_lista_personalizada, null);
        TextView txtview = convertView.findViewById(R.id.txt_gastos_ingresos);
        ImageView imgview = convertView.findViewById(R.id.img_gastos_ingresos);
        txtview.setText(lista_gastos[position]);
        imgview.setImageResource(lista_imgs[position]);
        return convertView;
    }
}
